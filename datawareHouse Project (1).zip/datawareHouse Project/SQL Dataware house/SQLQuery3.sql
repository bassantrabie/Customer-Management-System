CREATE TABLE DimCustomers (
    CustomerID INT PRIMARY KEY,
    FirstName VARCHAR(100),
    LastName VARCHAR(100),
    Email VARCHAR(255),
    PhoneNumber VARCHAR(20),
    DateOfBirth DATE,
    Gender VARCHAR(10)
);


CREATE TABLE DimProducts (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(255),
    Category VARCHAR(100),
    Price DECIMAL(10, 2)
);

CREATE TABLE DimDate (
    DateKey INT PRIMARY KEY, -- Use format YYYYMMDD as the key
    Date DATE,
    Year INT,
    Quarter INT,
    Month INT,
    Day INT,
    Weekday VARCHAR(10)
);
CREATE TABLE FactTransactions (
    TransactionID INT PRIMARY KEY IDENTITY(1,1),
    CustomerID INT, -- Links to DimCustomers
    ProductID INT, -- Links to DimProducts
    TransactionDateKey INT, -- Links to DimDate
    Quantity INT NOT NULL,
    TotalAmount DECIMAL(10, 2) NOT NULL,
    PaymentMethod VARCHAR(50),
    Status VARCHAR(20),
    FOREIGN KEY (CustomerID) REFERENCES DimCustomers(CustomerID),
    FOREIGN KEY (ProductID) REFERENCES DimProducts(ProductID),
    FOREIGN KEY (TransactionDateKey) REFERENCES DimDate(DateKey)
);

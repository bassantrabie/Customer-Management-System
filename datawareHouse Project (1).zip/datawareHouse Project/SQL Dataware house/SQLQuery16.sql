INSERT INTO DimCustomers (CustomerID, FirstName, LastName, Email, PhoneNumber, DateOfBirth, Gender)
SELECT CustomerID, FirstName, LastName, Email, PhoneNumber, DateOfBirth, Gender
FROM DatawareHouse.dbo.cleaned_customers;

INSERT INTO DimProducts (ProductID, ProductName, Category, Price)
SELECT ProductID, ProductName, Category, Price
FROM DatawareHouse.dbo.products;

INSERT INTO DimDate (DateKey, Date, Year, Quarter, Month, Day, Weekday)
SELECT 
    CAST(FORMAT(TransactionDate, 'yyyyMMdd') AS INT) AS DateKey,
    CAST(TransactionDate AS DATE) AS Date,
    YEAR(TransactionDate) AS Year,
    DATEPART(QUARTER, TransactionDate) AS Quarter,
    MONTH(TransactionDate) AS Month,
    DAY(TransactionDate) AS Day,
    DATENAME(WEEKDAY, TransactionDate) AS Weekday
FROM DatawareHouse.dbo.Transactions
GROUP BY 
    CAST(FORMAT(TransactionDate, 'yyyyMMdd') AS INT), 
    CAST(TransactionDate AS DATE), 
    YEAR(TransactionDate),
    DATEPART(QUARTER, TransactionDate),
    MONTH(TransactionDate), 
    DAY(TransactionDate), 
    DATENAME(WEEKDAY, TransactionDate);






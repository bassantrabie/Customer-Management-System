INSERT INTO CustomersDW.dbo.FactTransactions (CustomerID, ProductID, TransactionDateKey, Quantity, TotalAmount, PaymentMethod, Status)
SELECT 
    T.CustomerID, 
    TD.ProductID, 
    CAST(FORMAT(T.TransactionDate, 'yyyyMMdd') AS INT) AS TransactionDateKey,  -- Format date as required
    TD.Quantity, 
    T.TotalAmount, 
    T.PaymentMethod, 
    T.Status
FROM DatawareHouse.dbo.Transactions T  -- Source Transactions table
JOIN DatawareHouse.dbo.TransactionsDetails TD ON T.TransactionID = TD.TransactionID -- Correct table name for TransactionDetails
JOIN CustomersDW.dbo.DimCustomers DC ON T.CustomerID = DC.CustomerID  -- Ensure valid CustomerIDs
JOIN CustomersDW.dbo.DimProducts DP ON TD.ProductID = DP.ProductID  -- Ensure valid ProductIDs
JOIN CustomersDW.dbo.DimDate DD ON CAST(T.TransactionDate AS DATE) = DD.Date;  -- Assuming DimDate has a Date column


